"""
This is an example of Google style.

Args:

Returns:


"""
