"""
This is an example of Google style.

Args:

Returns:


"""

__version__ = "0.0.1"
